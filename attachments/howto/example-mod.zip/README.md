# My Hecking Cool Mod!

This is a readme for my cool as heck mod. I understand that uploading the default readme will make me look goofy in front of the whole community.
